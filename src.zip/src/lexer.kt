

class Lexer(val text: String) {
    private var pos: Int = 0
    private var currentChar: Char? = null
    private var prevChar: Char? = null
    init {
        currentChar = text[pos]
    }
    public fun nextToken(): Token {
        while (currentChar != null) {
            if (currentChar!!.isWhitespace()) {
                skip()
                continue
            }
            if (currentChar!!.isDigit()) {
                return Token(TokenType.NUMBER, number())
            }
            if (currentChar == '+') {
                forward()
                return Token(TokenType.PLUS, "$currentChar")
            }
            if (currentChar == '-') {
                forward()
                return Token(TokenType.MINUS, "$currentChar")
            }
            if (currentChar == '*') {
                forward()
                return Token(TokenType.MUL, "$currentChar")
            }
            if (currentChar == '/') {
                forward()
                return Token(TokenType.DIV, "$currentChar")
            }

            throw InterpreterException("invalid token")
        }
        return Token(TokenType.EOL, "")
    }

    private fun forward() {
        pos += 1
        if (pos > text.length - 1) {
            currentChar = null
        }
        else {
            currentChar = text[pos]
        }
    }

    private fun skip() {
        while ((currentChar != null) && currentChar!!.isWhitespace()){
            forward()
        }
    }

    private fun number(): String {
        var result = arrayListOf<Char>()
        while ((currentChar != null) && (currentChar!!.isDigit() || currentChar == '.')) {
            result.add(currentChar!!)
            forward()
        }
        return result.joinToString("")
    }
}