
class InterpreterException(message: String): Exception(message)

class Interpreter(private val lexer: Lexer) {
    private lateinit var currentToken: Token
    private var unMinus = false
    private fun checkTokenType(type: TokenType){
        if (currentToken.type == type) {
            currentToken = lexer.nextToken()
        }
        else {
            throw InterpreterException("invalid token order")
        }
    }

    private fun factor(): Double {
        val token = currentToken
        when (token.type) {
            TokenType.NUMBER -> {
                checkTokenType(TokenType.NUMBER)
            }
            TokenType.MINUS -> {
                checkTokenType(TokenType.MINUS)
                unMinus = !unMinus
                return factor()
            }
        }
        var result = if (unMinus) -token.value.toDouble() else token.value.toDouble()
        unMinus = if (unMinus) !unMinus else unMinus
        return result
    }

    private fun term(): Double {
        val ops = arrayListOf<TokenType>(TokenType.MUL, TokenType.DIV)
        var result = factor()

        while (ops.contains(currentToken.type)) {
            val token = currentToken
            when (token.type) {
                TokenType.DIV -> {
                    checkTokenType(TokenType.DIV)
                    result /= factor()
                }
                TokenType.MUL -> {
                    checkTokenType(TokenType.MUL)
                    result *= factor()
                }
            }
        }
        return result
    }
    fun expr(): Double {
        currentToken = lexer.nextToken()
        val ops = arrayListOf<TokenType>(TokenType.PLUS, TokenType.MINUS)
        var result = term()

        while (ops.contains(currentToken.type)) {
            val token = currentToken
            if (token.type == TokenType.PLUS) {
                checkTokenType(TokenType.PLUS)
                result += term()
            }
            if (token.type == TokenType.MINUS) {
                checkTokenType(TokenType.MINUS)
                result -= term()
            }
        }
        return result
        /*
        val left = currentToken
        checkTokenType(TokenType.INTEGER)
        val op = currentToken
        if (op.type == TokenType.PLUS) {
            checkTokenType(TokenType.PLUS)
        }else {
            checkTokenType(TokenType.MINUS)
        }
        val right = currentToken
        checkTokenType(TokenType.INTEGER)
        if (op.type == TokenType.PLUS) {
            return left.value.toInt() + right.value.toInt()
        }
        else {
            return left.value.toInt() - right.value.toInt()
        }*/
    }
}